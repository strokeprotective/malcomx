from django.shortcuts import render
import wolframalpha

# Create your views here.
def home(request):
    return render(request, 'home.html')
def searchnut(request):
    app_id = 'XG42RH-HXG4R55PJP'
    client = wolframalpha.Client(app_id)
    search = request.POST.get('search')
    res = client.query(search)
    print(next(res.results).text)
    results = next(res.results).text
    print(results)
    my_context = {
        "my_text": "Hello",
        'results' : results
    }
    return render(request, 'searchnut.html', my_context)



